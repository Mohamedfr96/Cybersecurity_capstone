<?php
define("PROJECT_HOME","http://localhost/");

define("PORT", "587"); // port number
define("MAIL_USERNAME", "49d1f30a83bc5be1e5a8a02ae0f37129"); // smtp usernmae
define("MAIL_PASSWORD", "fc055a14edde59bedb493bbfccc96791"); // smtp password
define("MAIL_HOST", "in-v3.mailjet.com"); // smtp host
define("MAILER", "smtp");

define("SENDER_NAME", "return-zero");
define("SERDER_EMAIL", "ahmedandaloesg@gmail.com");
?>
